#include <pthread.h>
#include <jni.h>
#include <Substrate/SubstrateHook.h>
#include "Unity/Quaternion.hpp"
#include "Unity/Vector2.hpp"
#include "Unity/Vector3.hpp"
#include "Unity/Unity.h"
#include "Unity/Hook.h"
#include "Unity/Global.h"
#include "Unity/Color.hpp"
#include "Unity/Rect.hpp"
#include "Unity/ESP.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"

# define HOOK_32(offset, ptr, orig) MSHookFunction((void *)getRealOffset(offset), (void *)ptr, (void **)&orig)

using namespace std;

ESP espOverlay;

struct My_Patches {
	
    MemoryPatch exemplo;
	
} Patches;


struct {
    
    bool aimProximo = true;
	bool aimAuto = false;
    bool aimScope = true;
    bool aimFire = true;
    bool aimSquat = false;
    bool aimLegit = false;
    bool aimVisible = true;
    bool aimbotauto = false;

    bool AlertAround = true;
	bool espIndetificar = true;
    bool espFPS = true;
    bool configLine = true;
    bool espDistance = true;
    bool espNames = true;
    bool espBox = true;
    bool espSkeleton = true;
	bool espGranada = true;
	bool espName = true;
	bool espAlvo = true;
	
	bool aimCabeca = true;
	bool aimPeito = false;
	bool aimPe = false;
	
	bool espNewConfig = false;
	bool espNew1 = false;
	bool espNew2 = false;
	bool espNew3 = false;
	bool espNew4 = false;
    
	bool espLineEncima = true;
	bool espLineEmbaixo = false;
	
	bool trandom = false;
	bool random = false;
	
	int semihs = 0;
    int FramePerS;
    int enemyCountAround = 0;
    int botCountAround = 0;
    
	Color GranadaColor = Color::Red();
    Color LineColor = Color::White();
    Color TextColor = Color::White();
	Color CaidosCor = Color::Red();
    
	float Fov_Aim = 4.0f;
	float Aim_Smooth = 0.0f;
    float TextSize = 17.0f;
    float LineSize = 1.0f;
	
	bool enableFov = true;

} HP;

Vector3 GetHeadPosition(void* player)
{
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.HeadTF));
}

Vector3 GetHipPosition(void* player)
{
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.HipTF));
}

Vector3 GetToePosition(void* player)
{
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.ToeTF));
}

Vector3 CameraMain(void* player)
{
    return Transform_INTERNAL_GetPosition(*(void**) ((uint64_t) player + Global.MainCameraTransform));
}

void* GetLocalEnemy(void *match)
{
	if(!match)
	{
		return nullptr;
	}
	
	float angleAffinity = 99999;
	float aimFov = HP.Fov_Aim;
	float aimSmooth = HP.Aim_Smooth;
	
	void* enemy_player = nullptr;
    void* LocalPlayer = GetLocalPlayer(match);
	
	if(LocalPlayer != nullptr && !get_IsDieing(LocalPlayer))
	{
		monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t*, void **> **)((long)match + Global.Dictionary);
		for(int u = 0; u < players->getNumValues(); u++)
		{
			void* Player = players->getValues()[u];
			
			if(Player != nullptr && !get_IsDieing(Player) && !get_isLocalTeam(Player) && get_isVisible(Player) && get_MaxHP(Player))
			{
				Vector3 playerHip = GetHipPosition(LocalPlayer);
				Vector3 enemyHip = GetHipPosition(Player);
				
				float distanceToMe = Vector3::Distance(enemyHip, playerHip);
				
				if(!HP.aimProximo)
				{
					Vector3 fwd = GetForward(Component_GetTransform(Camera_main())) * aimFov;
					Vector3 nrml = Vector3::Normalized(enemyHip - playerHip);
					
					float angle = Vector3::Angle(nrml, fwd);
					
					if(angle <= aimFov)
					{
						if(distanceToMe < angleAffinity)
						{
							angleAffinity = distanceToMe;
							enemy_player = Player;
						}
					}
				}
				else
				{
					if(distanceToMe < angleAffinity)
					{
                        angleAffinity = distanceToMe;
                        enemy_player = Player;
                    }
				}
			}
        }
	}
	return enemy_player;
}

void *Grenade2 = nullptr;

void *Render2 = nullptr;

void (*_GrenadeLine_Update)(void *instance);
void GrenadeLine_Update(void *instance) {
    if (instance) {
        Grenade2 = instance;
        *(bool *)((uint64_t)instance + Global.GrenadeLine_isVisible) = true;
        Render2 = *(void **)((uint64_t)instance + Global.GrenadeLine_m_GrenadeLine);
    }
    _GrenadeLine_Update(instance);
}

void AimBot(void *local_player, void *enemy_player)
{
	if(local_player != nullptr)
	{
		if(enemy_player != nullptr)
		{
			Vector3 EnemyLocation = GetHeadPosition(enemy_player);
			Vector3 CenterWS = GetAttackableCenterWS(local_player);
			float distance = Vector3::Distance(CenterWS, EnemyLocation);
			
			if (HP.espNames)
			{
				void *ui = CurrentUIScene();
				if (ui != nullptr)
				{
					monoString *nick = get_NickName(enemy_player);
					monoString *distances = U3DStrFormat(distance);
					ShowAssistantText(ui, nick, distances);
				}
			}
				
			if(HP.espGranada)
			{
				if (Grenade2 != nullptr && Render2 != nullptr)
				{
					Vector3 From = GetAttackableCenterWS(local_player);
					GrenadeLine_DrawLine(Grenade2, From, From, Vector3(0, 1, 0) * 0.6);
					((void (*)(void *, Color))getRealOffset(Global.set_startColor))(Render2, HP.GranadaColor);
					((void (*)(void *, Color))getRealOffset(Global.set_endColor))(Render2, HP.GranadaColor);
					LineRenderer_Set_PositionCount(Render2, 0x2);
					LineRenderer_SetPosition(Render2, 0x0, From);
					LineRenderer_SetPosition(Render2, 0x1, EnemyLocation);
				}
			}
			
			//if(TargetVisible(local_player, enemy_player))
		//	{
				Quaternion PlayerHead = LookRotation(GetHeadPosition(enemy_player), CameraMain(local_player));
				Quaternion PlayerHip = LookRotation(GetHipPosition(enemy_player), CameraMain(local_player));
				Quaternion PlayerToe = LookRotation(GetToePosition(enemy_player), CameraMain(local_player));
				
				if (HP.aimAuto)
				{
					if(HP.aimCabeca)
					{
						set_aim(local_player, PlayerHead);
					}
					
					if(HP.aimPeito)
					{
						set_aim(local_player, PlayerHip);
					}
					
					if(HP.aimPe)
					{
						set_aim(local_player, PlayerToe);
					}
				}
				
				bool firing = get_IsFiring(local_player);
				
				if (firing && HP.aimFire)
				{
					if(HP.aimCabeca)
					{
						set_aim(local_player, PlayerHead);
					}
					
					if(HP.aimPeito)
					{
						set_aim(local_player, PlayerHip);
					}
					
					if(HP.aimPe)
					{
						set_aim(local_player, PlayerToe);
					}
				}
				
				bool scope = get_IsSighting(local_player);
				
				if (scope && HP.aimScope)
				{
					if(HP.aimCabeca)
					{
						set_aim(local_player, PlayerHead);
					}
					
					if(HP.aimPeito)
					{
						set_aim(local_player, PlayerHip);
					}
					
					if(HP.aimPe)
					{
						set_aim(local_player, PlayerToe);
					}
				}
				
				if (firing && HP.aimLegit)
				{
					if(HP.aimCabeca)
					{
						set_aim(local_player, PlayerHead);
					}
					
					if(HP.aimPeito)
					{
						set_aim(local_player, PlayerHip);
					}
					
					if(HP.aimPe)
					{
						set_aim(local_player, PlayerToe);
					}
				}
				
				bool agachado = get_IsCrouching(local_player);
				
				if (agachado && HP.aimSquat)
				{
					if(HP.aimCabeca)
					{
						set_aim(local_player, PlayerHead);
					}
					
					if(HP.aimPeito)
					{
						set_aim(local_player, PlayerHip);
					}
					
					if(HP.aimPe)
					{
						set_aim(local_player, PlayerToe);
					}
			//	}
			}
		}
	}
}

void (*LateUpdate)(void *componentPlayer);

void *fakeEnemy;
bool espArray = false;
void _LateUpdate(void *player)
{
	if(player != nullptr)
	{
		void *current_match = Curent_Match();
		
		if(current_match != nullptr)
		{
			void *local_player = GetLocalPlayer(current_match);
			
			if (HP.AlertAround)
			{
				monoString* count = FormatCount(HP.enemyCountAround + HP.botCountAround);
				if(count != nullptr)
				{
					ShowDynamicPopupMessage(count);
				}
			}
			
			if(!espArray)
			{
				int tmpEnemyCountAround = 0;
                int tmpBotCountAround = 0;
            
                monoDictionary<uint8_t *, void **> *players = *(monoDictionary<uint8_t *, void **> **) ((long) current_match + 0x44);
                for (int u = 0; u < players->getNumValues(); u++) {
                    void *closestEnemy = players->getValues()[u];
                    
                    HP.enemyCountAround = tmpEnemyCountAround;
                    HP.botCountAround = tmpBotCountAround;
                    
                    if(closestEnemy != nullptr && closestEnemy != player && !get_isLocalTeam(closestEnemy) && get_isVisible(closestEnemy) && get_MaxHP(closestEnemy)) {
                    
                        if (closestEnemy != nullptr) {
                            bool isBot = *(bool*)((uintptr_t)closestEnemy + Global.IsClientBot);
                            if (isBot) {
                                ++tmpBotCountAround;
                            } else {
                                ++tmpEnemyCountAround;
                            }
                        }
                        
                        if(closestEnemy != local_player) {
                            // Lugar para funções materiais - Dispositivo potente
                        }
                    }
                }
			}
			
			if (local_player != nullptr)
			{
				void *fakeCamPlayer = get_MyFollowCamera(local_player);
				void *fakeCamEnemy = get_MyFollowCamera(player);
				
				if (fakeCamPlayer != nullptr && fakeCamEnemy != nullptr)
				{
					void* enemy_player = GetLocalEnemy(current_match);
					
					if(enemy_player != nullptr)
					{
						AimBot(local_player, enemy_player);
					}
					
					void *fakeCamPlayerTF = Component_GetTransform(fakeCamPlayer);
                    void *fakeCamEnemyTF = Component_GetTransform(player);
					
					if (fakeCamPlayerTF != nullptr && fakeCamEnemyTF != nullptr)
					{
						Vector3 fakeCamPlayerPos = Transform_INTERNAL_GetPosition(fakeCamPlayerTF);
                        Vector3 fakeCamEnemyPos = Transform_INTERNAL_GetPosition(fakeCamEnemyTF);
                        float distance = Vector3::Distance(fakeCamPlayerPos, fakeCamEnemyPos);
						
						if (player != local_player)
						{
                            if (distance < 1.6f)
							{
                                fakeEnemy = player;
                            }
                        }
					}
				}
			}
		}
	}
    LateUpdate(player);
}

void (*DoUpdate)(void* Counter); // COW.FpsCounter

void _DoUpdate(void* Counter)
{
    if (Counter != nullptr)
	{
        HP.FramePerS =  *(int*)((uint64_t)Counter + 0x14);
    }
	DoUpdate(Counter);
}

const char* name = "libil2cpp.so";

void *hack_thread(void *)
{
	LOGI("pthread called");
	
    ProcMap il2cppMap;
    do
	{
        il2cppMap = KittyMemory::getLibraryMap(name);
        sleep(1);
    }
	while (!il2cppMap.isValid());
    
	LOGI("%s has been loaded", (const char *) name);
	
	HOOK_32(0x1F5FB7C,_DoUpdate,DoUpdate); // FPS counter
	HOOK_32(0xC39718,_LateUpdate,LateUpdate); // LateUpdate
	MSHookFunction((void *)getRealOffset(Global.GrenadeLine_Update), (void *)GrenadeLine_Update, (void **)&_GrenadeLine_Update);
	
	return nullptr;
}

bool launched = false;

extern "C"
__attribute__((visibility("default")))
void OnInject(char *) {
    if (!launched) {
        launched = true;
        pthread_t ptid;
		pthread_create(&ptid, nullptr, hack_thread, nullptr);
    }
}

__attribute__((constructor))
void OnCreate() {
    if (!launched) {
        launched = true;
        pthread_t ptid;
		pthread_create(&ptid, nullptr, hack_thread, nullptr);
    }
}
