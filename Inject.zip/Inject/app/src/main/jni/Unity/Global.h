#ifndef ANDROID_MOD_MENU_GLOBAL_H
#define ANDROID_MOD_MENU_GLOBAL_H

struct {
	
	
   /*---------- TRANSFORM POSITION -----------*/
	
	uintptr_t HeadTF = 0x1C8; // protected Transform JoqBDUR; 2
    uintptr_t HipTF = 0x1CC; // 3
    uintptr_t ToeTF = 0x1DC;  // 
    uintptr_t OmbroD = 0x1F8; // 13
    uintptr_t OmbroE = 0x1FC; // 14i
    uintptr_t PernaD = 0x1E4; // 9
    uintptr_t PernaE = 0x1E0; // 8
    uintptr_t BracoD = 0x1F0; // 12
    uintptr_t BracoE = 0x1C4; // 1

	
	
	/*------------ TRANSFORM DIRITORIO ----------*/
	
    uintptr_t MainCameraTransform = 0x5C;
    uintptr_t Dictionary = 0x44; //internal class `ZtmgF(){}
    uintptr_t IsClientBot = 0xDC;
    uintptr_t Transform_INTERNAL_GetPosition = 0x29F20D4;
	uintptr_t GrenadeLine_isVisible = 0xC;
	uintptr_t GrenadeLine_m_GrenadeLine = 0x10;
	
	/*---------- Linha Granada -----------*/
	
	uintptr_t LineRenderer_Set_PositionCount = 0x29143D4;//1.60 certa
    uintptr_t LineRenderer_SetPosition = 0x2914480;//1.60 certa
    uintptr_t GrenadeLine_DrawLine = 0xDF1E9C;//1.60 certa
    uintptr_t GrenadeLine_Update = 0xDF1978;//1.60 certa
	uintptr_t set_startColor = 0x29141F4;
	uintptr_t set_endColor = 0x2914298;
	
	/* ---------- Obter -----------*/
	
    uintptr_t get_IsFiring = 0x7F8CC0;
    uintptr_t get_IsSighting = 0x871B30;
    uintptr_t get_isLocalTeam = 0x819958;
    uintptr_t get_isVisible = 0x812BFC;//public override bool IsVisible() { }
    uintptr_t get_MaxHP = 0x8477B0;//public int get_MaxHP() { }
    uintptr_t get_IsDieing = 0x7FFAE8;//public bool get_IsDieing() { }
    uintptr_t get_IsCrouching = 0x81B374;//public bool IsCrouching() { }
	uintptr_t get_NickName = 0x810084;//public string get_NickName() { }
	uintptr_t get_isAlive = 0x8606A4;//public bool IsCameraTrackableEntityAlive() { }
	uintptr_t get_MyFollowCamera = 0x81099C;//public FollowCamera get_MyFollowCamera() { }
	
	/*---------- Setar -----------*/
	
	uintptr_t set_aim = 0x810F18;// public void SetAimRotation(Quaternion laYChSW) { }
    uintptr_t get_imo = 0x815E30;// GetActiveWeapon() { }
    uintptr_t set_esp = 0x15FDD24;// public void utKBmvc(Vector3 RvOJF{, Vector3 bQiMI) { }
	
	/*---------- Popup -----------*/
	
	uintptr_t AddTeammateHud = 0x93A984;//public void ShowAssistantText(string playerName, string line) { }
    uintptr_t ShowDynamicPopupMessage = 0x923BC8;//
    uintptr_t ShowPopupMessage = 0x923D08;//
	uintptr_t U3DStr = 0x27A4238;//private string CreateString(sbyte* value) { }
	uintptr_t CurrentUIScene = 0x11B46DC;//public static UICOWBaseScene CurrentUIScene() { }
	uintptr_t String_Concat = 0x2795C5C; //public static string Concat(string str0, string str1) { } 1.60 certa
	uintptr_t ShowAssistantText = 0x93A984;
		
	/*------------ Player ----------*/
	
	uintptr_t Component_GetTransform = 0x27FA17C;//public Transform get_transform() { }
    uintptr_t GetForward = 0x29F2C34;//public Vector3 get_forward() { }
	uintptr_t GetAttackableCenterWS = 0x80FB18;//
	uintptr_t GetLocalPlayer = 0x113F558;//private static Player GetLocalPlayer() { }
	uintptr_t Current_Local_Player = 0x11CCED4;//public static Player CurrentLocalPlayer() { }
    uintptr_t GetLocalPlayerOrObServer = 0x11CE59C;//public static Player GetLocalPlayerOrObserverTarget() { }
    uintptr_t GetPhysXPose = 0x7F8D0C; //public VCDxuoO GetPhysXPose() { }
	uintptr_t GetPhysXState = 0x81B2C0;//public Player.T[m GetPhysXState() { }
    uintptr_t Player_Index = 0x9EA604; //public Player hszKW]() { } certa
	uintptr_t get_CurHP = 0x847738; //public int get_CurHP() { } 1.60 certa
	uintptr_t get_HasHelmet = 0x8102BC; //public bool get_HasHelmet() { } 1.60 certa
    uintptr_t get_HasVest = 0x810200; //public bool get_HasVest() { } 1.60 certa
    uintptr_t IsSkyDiving = 0x7F8A1C; //public bool get_IsSkyDiving() { } 1.60 certa
	uintptr_t GetPlayerCaido = 0x7FFAE8; //public bool get_IsDieing() { } 1.60 certa
	uintptr_t RealDead = 0x811368; //public bool get_IsReallyDead() { } 1.60 certa
    uintptr_t IsFiring = 0x7F8CC0; //public bool IsFiring() { } 1.60 certa
    uintptr_t get_IsReallyDead = 0x811368; // public bool get_IsReallyDead 1.60
   
	
	/*------------ Outros -----------*/
	
    uintptr_t Curent_Match = 0x11CCBB0;//public static  CurrentMatch() { }
    uintptr_t Camera_main = 0x27F8680;//public static Camera get_main() { }
    uintptr_t WorldToScreenPoint = 0x27F7F90;
    uintptr_t get_height = 0x29E6810; //public static int get_height() { } 1.60 certa
    uintptr_t get_width = 0x29E678C; //pub"|lic static int get_width() { } 1.60 certa
	uintptr_t get_IsDriver = 0x7F6654;//Carro
	uintptr_t GetIsDead = 0xFD7E8C; //public bool get_IsDead() { } 1.60 certa
    uintptr_t IsParachuting = 0x7F89E0; //public bool get_IsParachuting() { } 1.60 certa
    uintptr_t get_Chars = 0x2796340;
    uintptr_t AttackableEntity_GetIsDead = 0xFD7E8C;
	
} Global;

#endif
