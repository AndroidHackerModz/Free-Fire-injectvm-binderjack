package com.hidden.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import com.topjohnwu.superuser.Shell;
import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import com.topjohnwu.superuser.internal.ShellTerminatedException;

public class MainActivity extends Activity {

	public void showNoRootMessage() {
		(new AlertDialog.Builder(MainActivity.this))
			.setMessage("Não foi possível adquirir acesso ao root")
			.setNegativeButton(android.R.string.ok, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface p1, int p2) {
					finishAffinity();
				}
			})
			.show();
	}

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

		findViewById(R.id.Start).setOnClickListener(new View.OnClickListener() {

				@Override
				public void onClick(View v) {
					Inject();
				}
			});
    }

	private void Inject() {
		try {

			String target = "com.dts.freefireth";

			String injector = this.getApplicationInfo().nativeLibraryDir + File.separator + "libinject.so";
			String payload_source = this.getApplicationInfo().nativeLibraryDir + File.separator + "libHidden.so";
			String payload_dest = "/data/local/tmp/libHidden.so";
			String context = "u:object_r:system_lib_file:s0";
			
			List<String> STDOUT = new ArrayList<>();
			Shell.su("ls -lZ /system/lib/libandroid_runtime.so").to(STDOUT).exec();
			for (String line : STDOUT) {
				if (line.contains(" u:object_r:") && line.contains(":s0 ")) {
					context = line.substring(line.indexOf("u:object_r:"));
					context = context.substring(0, context.indexOf(' '));
				}
			}

			Shell.su("cp " + payload_source + " " + payload_dest).exec();
			Shell.su("chmod 777 " + payload_dest).exec();
			Shell.su("chcon " + context + " " + payload_dest).exec();

			try {
				this.startActivity(this.getPackageManager().getLaunchIntentForPackage(target));
			} catch (Exception e) {
				// no action
			}

			while (Utils.getProcessID(target) <= 0) {}
			Thread.sleep(1000);

			int pid = Utils.getProcessID(target);
			String command = String.format(Locale.ENGLISH,"%s %d %s", injector, pid, payload_dest);

			Shell.su(command).exec();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
