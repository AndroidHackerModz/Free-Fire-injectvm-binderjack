package com.hidden.pro;

import android.app.Application;
import com.topjohnwu.superuser.Shell;
import java.io.IOException;

public class HDApplication extends Application {

	@Override
	public void onCreate() {
		super.onCreate();
		try {
			Runtime.getRuntime().exec("su");
			if (Shell.rootAccess()) {
				Shell.su("setenforce 0").submit();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
